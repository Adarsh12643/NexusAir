-- initial_schema.sql
-- Flight Management DB Setup

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. Tables Creation

CREATE TABLE flights (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    flight_no VARCHAR(10) NOT NULL,
    origin VARCHAR(3) NOT NULL,
    destination VARCHAR(3) NOT NULL,
    departs_at TIMESTAMPTZ NOT NULL,
    arrives_at TIMESTAMPTZ NOT NULL,
    aircraft_type VARCHAR(50) NOT NULL,
    status VARCHAR(20) DEFAULT 'scheduled',
    base_price DECIMAL(10, 2) NOT NULL
);

CREATE TABLE seats (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    flight_id UUID REFERENCES flights(id) ON DELETE CASCADE,
    seat_number VARCHAR(5) NOT NULL,
    class VARCHAR(20) NOT NULL CHECK (class IN ('economy', 'business', 'first')),
    is_available BOOLEAN DEFAULT true,
    extra_fee DECIMAL(10, 2) DEFAULT 0.00,
    UNIQUE(flight_id, seat_number)
);

CREATE TABLE bookings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL, -- references auth.users in actual implementation
    flight_id UUID REFERENCES flights(id),
    seat_id UUID REFERENCES seats(id),
    status VARCHAR(20) DEFAULT 'confirmed' CHECK (status IN ('confirmed', 'rescheduled', 'cancelled')),
    booked_at TIMESTAMPTZ DEFAULT NOW(),
    total_price DECIMAL(10, 2) NOT NULL,
    pnr_code VARCHAR(10) UNIQUE NOT NULL
);

CREATE TABLE passengers (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    booking_id UUID REFERENCES bookings(id) ON DELETE CASCADE,
    full_name VARCHAR(255) NOT NULL,
    passport_no VARCHAR(50) NOT NULL,
    nationality VARCHAR(50) NOT NULL,
    dob DATE NOT NULL
);

CREATE TABLE reschedules (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    booking_id UUID REFERENCES bookings(id),
    old_flight_id UUID REFERENCES flights(id),
    new_flight_id UUID REFERENCES flights(id),
    requested_at TIMESTAMPTZ DEFAULT NOW(),
    fee_charged DECIMAL(10, 2) DEFAULT 0.00
);

-- 2. Row Level Security (RLS)

ALTER TABLE flights ENABLE ROW LEVEL SECURITY;
ALTER TABLE seats ENABLE ROW LEVEL SECURITY;
ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE passengers ENABLE ROW LEVEL SECURITY;
ALTER TABLE reschedules ENABLE ROW LEVEL SECURITY;

-- Read rules
-- Flights and seats are public
CREATE POLICY "Flights are viewable by everyone" ON flights FOR SELECT USING (true);
CREATE POLICY "Seats are viewable by everyone" ON seats FOR SELECT USING (true);

-- Bookings, Passengers, Reschedules are limited to the user who owns them
CREATE POLICY "Users can view their own bookings" ON bookings FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can view their own passengers" ON passengers FOR SELECT USING (
    booking_id IN (SELECT id FROM bookings WHERE user_id = auth.uid())
);
CREATE POLICY "Users can view their own reschedules" ON reschedules FOR SELECT USING (
    booking_id IN (SELECT id FROM bookings WHERE user_id = auth.uid())
);

-- Users can insert their own bookings
CREATE POLICY "Users can insert their own bookings" ON bookings FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update their own bookings" ON bookings FOR UPDATE USING (auth.uid() = user_id);

-- 3. Functions & Triggers

-- RPC for booking a seat atomically
CREATE OR REPLACE FUNCTION reserve_seat(p_seat_id UUID, p_user_id UUID, p_flight_id UUID, p_total_price DECIMAL, p_pnr_code VARCHAR)
RETURNS UUID AS $$
DECLARE
    v_booking_id UUID;
    v_is_available BOOLEAN;
BEGIN
    -- Explicitly lock the seat row to prevent double booking race condition
    SELECT is_available INTO v_is_available FROM seats WHERE id = p_seat_id FOR UPDATE;
    
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Seat not found';
    END IF;

    IF NOT v_is_available THEN
        RAISE EXCEPTION 'Seat is already booked';
    END IF;

    -- Update seat availability
    UPDATE seats SET is_available = false WHERE id = p_seat_id;

    -- Insert booking
    INSERT INTO bookings (user_id, flight_id, seat_id, status, booked_at, total_price, pnr_code)
    VALUES (p_user_id, p_flight_id, p_seat_id, 'confirmed', NOW(), p_total_price, p_pnr_code)
    RETURNING id INTO v_booking_id;

    RETURN v_booking_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;


-- RPC for cancelling a booking (updates status and frees seat)
CREATE OR REPLACE FUNCTION cancel_booking(p_booking_id UUID)
RETURNS BOOLEAN AS $$
DECLARE
    v_seat_id UUID;
BEGIN
    SELECT seat_id INTO v_seat_id FROM bookings WHERE id = p_booking_id FOR UPDATE;
    
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Booking not found';
    END IF;

    -- Free the seat
    UPDATE seats SET is_available = true WHERE id = v_seat_id;
    
    -- Update booking status
    UPDATE bookings SET status = 'cancelled' WHERE id = p_booking_id;
    
    RETURN true;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;


-- Enforce 2-hour cancellation rule at DB level
CREATE OR REPLACE FUNCTION enforce_cancellation_policy()
RETURNS TRIGGER AS $$
DECLARE
    v_flight_time TIMESTAMPTZ;
BEGIN
    IF NEW.status = 'cancelled' AND OLD.status != 'cancelled' THEN
        SELECT departs_at INTO v_flight_time FROM flights WHERE id = OLD.flight_id;
        
        IF (v_flight_time - NOW()) < INTERVAL '2 hours' THEN
            RAISE EXCEPTION 'Cannot cancel booking within 2 hours of departure';
        END IF;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER check_cancellation_time
BEFORE UPDATE ON bookings
FOR EACH ROW
EXECUTE FUNCTION enforce_cancellation_policy();


-- 4. Seed Data Script

DO $$
DECLARE
    f1 UUID; f2 UUID; f3 UUID; f4 UUID;
    f5 UUID; f6 UUID; f7 UUID; f8 UUID;
    i INT;
    seat_class VARCHAR;
    fee DECIMAL;
BEGIN
    f1 := uuid_generate_v4(); f2 := uuid_generate_v4();
    f3 := uuid_generate_v4(); f4 := uuid_generate_v4();
    f5 := uuid_generate_v4(); f6 := uuid_generate_v4();
    f7 := uuid_generate_v4(); f8 := uuid_generate_v4();

    INSERT INTO flights (id, flight_no, origin, destination, departs_at, arrives_at, aircraft_type, base_price) VALUES
    (f1, 'NX101', 'JFK', 'LHR', NOW() + INTERVAL '2 days', NOW() + INTERVAL '2 days 7 hours', 'Boeing 777', 450.00),
    (f2, 'NX102', 'LHR', 'JFK', NOW() + INTERVAL '5 days', NOW() + INTERVAL '5 days 8 hours', 'Boeing 777', 500.00),
    (f3, 'NX201', 'SFO', 'NRT', NOW() + INTERVAL '10 days', NOW() + INTERVAL '10 days 11 hours', 'Airbus A350', 800.00),
    (f4, 'NX202', 'NRT', 'SFO', NOW() + INTERVAL '15 days', NOW() + INTERVAL '15 days 9 hours', 'Airbus A350', 820.00),
    (f5, 'NX301', 'DXB', 'CDG', NOW() + INTERVAL '3 days', NOW() + INTERVAL '3 days 6 hours', 'Boeing 787', 350.00),
    (f6, 'NX302', 'CDG', 'DXB', NOW() + INTERVAL '8 days', NOW() + INTERVAL '8 days 6 hours', 'Boeing 787', 380.00),
    (f7, 'NX401', 'SIN', 'SYD', NOW() + INTERVAL '4 days', NOW() + INTERVAL '4 days 7 hours', 'Airbus A380', 400.00),
    (f8, 'NX402', 'SYD', 'SIN', NOW() + INTERVAL '7 days', NOW() + INTERVAL '7 days 8 hours', 'Airbus A380', 410.00);

    -- Seed seats for each flight (Simplified map: rows 1-2 First, 3-5 Bus, 6-20 Econ)
    FOR f_id IN SELECT id FROM flights LOOP
        FOR r IN 1..15 LOOP
            FOR c IN 1..4 LOOP
                -- Determine class
                IF r <= 2 THEN
                    seat_class := 'first'; fee := 500.00;
                ELSIF r <= 5 THEN
                    seat_class := 'business'; fee := 200.00;
                ELSE
                    seat_class := 'economy'; fee := 0.00;
                END IF;

                INSERT INTO seats (flight_id, seat_number, class, extra_fee)
                VALUES (f_id, r::VARCHAR || CHR(64 + c), seat_class, fee);
            END LOOP;
        END LOOP;
    END LOOP;
END $$;
