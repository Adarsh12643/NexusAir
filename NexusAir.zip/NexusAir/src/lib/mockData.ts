export const MOCK_FLIGHTS = [
  {
    id: "f1",
    flight_no: "NX101",
    origin: "JFK",
    destination: "LHR",
    departs_at: new Date(Date.now() + 2 * 86400000).toISOString(),
    arrives_at: new Date(Date.now() + 2 * 86400000 + 7 * 3600000).toISOString(),
    aircraft_type: "Boeing 777",
    status: "scheduled",
    base_price: 450.00
  },
  {
    id: "f2",
    flight_no: "NX102",
    origin: "LHR",
    destination: "JFK",
    departs_at: new Date(Date.now() + 5 * 86400000).toISOString(),
    arrives_at: new Date(Date.now() + 5 * 86400000 + 8 * 3600000).toISOString(),
    aircraft_type: "Boeing 777",
    status: "scheduled",
    base_price: 500.00
  },
  {
    id: "f3",
    flight_no: "NX201",
    origin: "SFO",
    destination: "NRT",
    departs_at: new Date(Date.now() + 10 * 86400000).toISOString(),
    arrives_at: new Date(Date.now() + 10 * 86400000 + 11 * 3600000).toISOString(),
    aircraft_type: "Airbus A350",
    status: "scheduled",
    base_price: 800.00
  },
  {
    id: "f4",
    flight_no: "NX401",
    origin: "SIN",
    destination: "SYD",
    departs_at: new Date(Date.now() + 4 * 86400000).toISOString(),
    arrives_at: new Date(Date.now() + 4 * 86400000 + 7 * 3600000).toISOString(),
    aircraft_type: "Airbus A380",
    status: "scheduled",
    base_price: 400.00
  }
];

export const generateMockSeats = (flightId: string) => {
  const seats = [];
  const chars = ['A', 'B', 'C', 'D'];
  for (let r = 1; r <= 15; r++) {
    for (let c = 0; c < 4; c++) {
      let seatClass = 'economy';
      let extra_fee = 0;
      if (r <= 2) { seatClass = 'first'; extra_fee = 500; }
      else if (r <= 5) { seatClass = 'business'; extra_fee = 200; }
      
      seats.push({
        id: `seat-${flightId}-${r}${chars[c]}`,
        flight_id: flightId,
        seat_number: `${r}${chars[c]}`,
        class: seatClass,
        is_available: Math.random() > 0.3, // 70% available
        extra_fee
      });
    }
  }
  return seats;
};
