/// <reference types="vite/client" />
import { createClient } from "@supabase/supabase-js";

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || "https://placeholder-url.supabase.co";
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || "placeholder-key";

// Use a real client if keys are provided, otherwise this will fail gracefully or we rely on mock data in the store
export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export const hasSupabaseConfig = 
  import.meta.env.VITE_SUPABASE_URL && import.meta.env.VITE_SUPABASE_URL !== '' &&
  import.meta.env.VITE_SUPABASE_ANON_KEY && import.meta.env.VITE_SUPABASE_ANON_KEY !== '';
