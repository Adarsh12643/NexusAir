import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { PageTransition } from '../components/PageTransition';
import { useFlightStore } from '../store/useFlightStore';
import { Plane, Calendar, Users, MapPin } from 'lucide-react';

export default function Home() {
  const navigate = useNavigate();
  const setSearchQuery = useFlightStore((state) => state.setSearchQuery);

  const [origin, setOrigin] = useState('JFK');
  const [destination, setDestination] = useState('LHR');
  const [date, setDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 2);
    return d.toISOString().split('T')[0];
  });
  const [passengers, setPassengers] = useState(1);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setSearchQuery({ origin, destination, date, passengers });
    navigate('/results');
  };

  return (
    <PageTransition>
      <div className="relative min-h-[calc(100vh-6rem)] flex flex-col items-center justify-center py-20 px-4 md:px-0">
        <div className="relative z-20 w-full max-w-4xl px-4 sm:px-6">
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-6xl font-bold tracking-tighter text-white mb-4 drop-shadow-xl">
              INITIALIZE <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-fuchsia-500">SEQUENCE</span>
            </h1>
            <p className="text-sm font-mono tracking-widest text-indigo-300 uppercase max-w-2xl mx-auto drop-shadow opacity-80">
              Set parameters for geospatial transport.
            </p>
          </div>

          <form 
            onSubmit={handleSearch}
            className="bg-white/5 backdrop-blur-xl p-6 md:p-8 rounded-[40px] shadow-2xl border border-white/10 ring-1 ring-white/5 transition-all w-full relative overflow-hidden group"
          >
            {/* Grid overlay */}
            <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:40px_40px] pointer-events-none z-0"></div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 relative z-10">
              
              {/* Origin */}
              <div className="bg-black/20 rounded-2xl p-4 border border-white/5 focus-within:ring-1 focus-within:ring-indigo-500 transition relative">
                <label className="text-[10px] font-semibold text-indigo-400 uppercase tracking-widest mb-2 block">Origin Node</label>
                <div className="flex items-center gap-3 text-white">
                  <MapPin className="w-5 h-5 text-indigo-500" />
                  <input 
                    type="text" 
                    value={origin}
                    onChange={(e) => setOrigin(e.target.value.toUpperCase())}
                    className="w-full font-bold text-lg bg-transparent border-none focus:outline-none uppercase placeholder:text-slate-600"
                    placeholder="JFK"
                    maxLength={3}
                    required
                  />
                </div>
              </div>

              {/* Destination */}
              <div className="bg-black/20 rounded-2xl p-4 border border-white/5 focus-within:ring-1 focus-within:ring-fuchsia-500 transition relative">
                <label className="text-[10px] font-semibold text-fuchsia-400 uppercase tracking-widest mb-2 block">Target Node</label>
                <div className="flex items-center gap-3 text-white">
                  <MapPin className="w-5 h-5 text-fuchsia-500" />
                  <input 
                    type="text" 
                    value={destination}
                    onChange={(e) => setDestination(e.target.value.toUpperCase())}
                    className="w-full font-bold text-lg bg-transparent border-none focus:outline-none uppercase placeholder:text-slate-600"
                    placeholder="LHR"
                    maxLength={3}
                    required
                  />
                </div>
              </div>

              {/* Date */}
              <div className="bg-black/20 rounded-2xl p-4 border border-white/5 focus-within:ring-1 focus-within:ring-indigo-500 transition relative md:col-span-1">
                <label className="text-[10px] font-semibold text-indigo-400 uppercase tracking-widest mb-2 block">Sync Date</label>
                <div className="flex items-center gap-3 text-white">
                  <Calendar className="w-5 h-5 text-indigo-500" />
                  <input 
                    type="date" 
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full font-mono text-sm bg-transparent border-none focus:outline-none [&::-webkit-calendar-picker-indicator]:invert-[1]"
                    required
                  />
                </div>
              </div>

              {/* Passengers */}
              <div className="bg-black/20 rounded-2xl p-4 border border-white/5 focus-within:ring-1 focus-within:ring-fuchsia-500 transition relative">
                <label className="text-[10px] font-semibold text-fuchsia-400 uppercase tracking-widest mb-2 block">Entities</label>
                <div className="flex items-center gap-3 text-white">
                  <Users className="w-5 h-5 text-fuchsia-500" />
                  <select 
                    value={passengers}
                    onChange={(e) => setPassengers(Number(e.target.value))}
                    className="w-full font-mono text-sm bg-transparent border-none focus:outline-none appearance-none [&>option]:bg-[#020205]"
                  >
                    {[1, 2, 3, 4, 5, 6].map(n => (
                      <option key={n} value={n}>{n} UNIT{n !== 1 ? 'S' : ''}</option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            <div className="mt-8 relative z-10">
              <button 
                type="submit"
                className="w-full bg-gradient-to-r from-indigo-600 to-fuchsia-600 hover:from-indigo-500 hover:to-fuchsia-500 text-white font-bold uppercase tracking-widest py-4 rounded-2xl flex items-center justify-center gap-3 transition-all shadow-[0_0_30px_rgba(99,102,241,0.3)] hover:shadow-[0_0_40px_rgba(217,70,239,0.4)]"
              >
                <Plane className="w-5 h-5 flex-shrink-0" />
                ENGAGE TRANSPORT
              </button>
            </div>
          </form>
        </div>
      </div>
    </PageTransition>
  );
}
