import { useState, useEffect } from 'react';
import { PageTransition } from '../components/PageTransition';
import { MOCK_FLIGHTS } from '../lib/mockData';
import { format, differenceInHours } from 'date-fns';
import { cn } from '../lib/utils';
import { Ticket, MapPin, Calendar, Clock, AlertTriangle, CheckCircle2, XCircle, Plane } from 'lucide-react';

// Simulated DB fetch for user's bookings
const fetchMockBookings = () => {
  return [
    {
      id: "b1",
      pnr_code: "XJDK92",
      status: "confirmed",
      flight_id: "f1",
      seat_number: "4A",
      class: "business",
      total_price: 650.00,
      booked_at: new Date(Date.now() - 4 * 86400000).toISOString()
    },
    {
      id: "b2",
      pnr_code: "M38LQA",
      status: "rescheduled",
      flight_id: "f3",
      seat_number: "2C",
      class: "first",
      total_price: 1300.00,
      booked_at: new Date(Date.now() - 15 * 86400000).toISOString()
    },
    {
      id: "b3",
      pnr_code: "Z940PL",
      status: "cancelled",
      flight_id: "f4",
      seat_number: "12B",
      class: "economy",
      total_price: 400.00,
      booked_at: new Date(Date.now() - 30 * 86400000).toISOString()
    }
  ];
};

export default function MyBookings() {
  const [bookings, setBookings] = useState<any[]>([]);
  const [cancelTarget, setCancelTarget] = useState<string | null>(null);
  
  useEffect(() => {
    setBookings(fetchMockBookings());
  }, []);

  const handleCancelBooking = (bookingId: string) => {
    // In real app, we call supabase.rpc('cancel_booking', { p_booking_id: bookingId })
    // If it fails due to 2 hour trigger, we catch exception
    setBookings(prev => 
      prev.map(b => b.id === bookingId ? { ...b, status: 'cancelled' } : b)
    );
    setCancelTarget(null);
  };

  const getStatusDisplay = (status: string) => {
    switch(status) {
      case 'confirmed': return { icon: <CheckCircle2 className="w-4 h-4" />, style: 'bg-green-500/20 text-green-400 border-green-500/30' };
      case 'rescheduled': return { icon: <AlertTriangle className="w-4 h-4" />, style: 'bg-amber-500/20 text-amber-400 border-amber-500/30' };
      case 'cancelled': return { icon: <XCircle className="w-4 h-4" />, style: 'bg-white/5 text-white/50 border-white/10' };
      default: return { icon: null, style: 'bg-white/5 text-white/50 border-white/10' };
    }
  };

  return (
    <PageTransition>
      <div className="max-w-5xl mx-auto px-4 py-12">
        <h1 className="text-3xl font-bold text-white tracking-tight mb-8 border-b border-white/10 pb-4">My Bookings</h1>

        <div className="space-y-6">
          {bookings.map(booking => {
            const flight = MOCK_FLIGHTS.find(f => f.id === booking.flight_id);
            if (!flight) return null;

            const isCancellable = booking.status !== 'cancelled' && differenceInHours(new Date(flight.departs_at), new Date()) > 2;

            return (
              <div key={booking.id} className={cn("bg-white/5 backdrop-blur-xl rounded-3xl shadow-xl border p-6 flex flex-col lg:flex-row lg:items-center gap-6 transition-all hover:bg-white/10", 
                booking.status === 'cancelled' ? "opacity-75 grayscale-[0.2]" : "border-white/10 hover:shadow-2xl hover:border-white/20"
              )}>
                {/* Header / PNR */}
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-4">
                    <span className="font-mono text-xl font-bold text-white border border-white/10 px-3 py-1 rounded-lg bg-black/40">
                      {booking.pnr_code}
                    </span>
                    <span className={cn("px-3 py-1 text-xs font-bold uppercase tracking-wider rounded-full border flex items-center gap-1", getStatusDisplay(booking.status).style)}>
                      {getStatusDisplay(booking.status).icon}
                      {booking.status}
                    </span>
                  </div>

                  <div className="flex items-center gap-4 text-white/50 text-sm font-mono uppercase tracking-wider">
                    <span className="font-bold text-white">{flight.flight_no}</span>
                    <span>•</span>
                    <span className="capitalize">{booking.class} Class</span>
                    <span>•</span>
                    <span>Seat <span className="font-bold text-white">{booking.seat_number}</span></span>
                  </div>
                </div>

                {/* Flight Route visual */}
                <div className="flex-1 flex items-center justify-between border-y lg:border-y-0 lg:border-x border-white/10 py-6 lg:py-0 lg:px-8 relative">
                  <div className="flex flex-col">
                    <span className="text-2xl font-bold text-white tracking-tight">{flight.origin}</span>
                    <span className="text-sm font-mono text-white/50 uppercase">{format(new Date(flight.departs_at), 'MMM d, HH:mm')}</span>
                  </div>
                  
                  <div className="flex-1 flex justify-center px-4">
                    <div className="w-full h-[2px] bg-white/10 relative flex items-center justify-center">
                      <Plane className="w-6 h-6 text-fuchsia-400 bg-transparent px-1 absolute drop-shadow-[0_0_10px_rgba(232,121,249,0.5)]" />
                    </div>
                  </div>

                  <div className="flex flex-col items-end">
                    <span className="text-2xl font-bold text-white tracking-tight">{flight.destination}</span>
                    <span className="text-sm font-mono text-white/50 uppercase">{format(new Date(flight.arrives_at), 'MMM d, HH:mm')}</span>
                  </div>
                </div>

                {/* Actions */}
                <div className="w-full lg:w-48 flex flex-col gap-3">
                  {booking.status !== 'cancelled' && (
                    <>
                      <button className="w-full font-bold text-xs uppercase tracking-wider border border-fuchsia-500/30 bg-fuchsia-500/10 hover:bg-fuchsia-500/20 text-fuchsia-300 rounded-xl py-3 transition shadow-[0_0_15px_rgba(168,85,247,0.1)] hover:shadow-[0_0_20px_rgba(168,85,247,0.3)]">
                        Reschedule
                      </button>
                      <button 
                        onClick={() => setCancelTarget(booking.id)}
                        disabled={!isCancellable}
                        className={cn(
                          "w-full font-bold text-xs uppercase tracking-wider border rounded-xl py-2.5 transition",
                          isCancellable 
                            ? "border-red-500/30 text-red-400 hover:bg-red-500/10 hover:border-red-500/50"
                            : "border-white/5 text-white/30 cursor-not-allowed bg-black/20"
                        )}
                        title={!isCancellable ? "Cannot cancel within 2 hours of departure" : ""}
                      >
                        Cancel Booking
                      </button>
                    </>
                  )}
                  {booking.status === 'cancelled' && (
                    <button className="w-full font-bold text-xs uppercase tracking-wider bg-white/10 text-white hover:bg-white/20 border border-white/10 rounded-xl py-3 transition">
                      Book Again
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Confirmation Dialog */}
      {cancelTarget && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-[#0b0a10] border border-white/10 rounded-3xl p-8 max-w-sm w-full shadow-[0_0_50px_rgba(0,0,0,0.5)]">
            <h3 className="text-xl font-bold text-white tracking-tight mb-2">Cancel Booking?</h3>
            <p className="text-white/60 text-sm mb-6 font-mono">
              Are you sure you want to cancel this booking? This action cannot be undone and your seat will be freed.
            </p>
            <div className="flex gap-4">
              <button 
                onClick={() => setCancelTarget(null)}
                className="flex-1 font-bold py-3 text-white/70 bg-white/5 hover:bg-white/10 border border-white/10 uppercase tracking-wider text-xs rounded-xl transition"
              >
                KEEP BOOKING
              </button>
              <button 
                onClick={() => handleCancelTarget(cancelTarget)}
                className="flex-1 font-bold py-3 text-white bg-red-600 hover:bg-red-500 shadow-[0_0_20px_rgba(220,38,38,0.4)] uppercase tracking-wider text-xs rounded-xl transition"
              >
                YES, CANCEL
              </button>
            </div>
          </div>
        </div>
      )}
    </PageTransition>
  );

  // Quick wrapper to fix undefined function
  function handleCancelTarget(id: string) {
    handleCancelBooking(id);
  }
}
