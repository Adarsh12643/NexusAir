import { useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { PageTransition } from '../components/PageTransition';
import { useFlightStore } from '../store/useFlightStore';
import { MOCK_FLIGHTS, generateMockSeats } from '../lib/mockData';
import { format } from 'date-fns';
import { CheckCircle2, Ticket, Printer } from 'lucide-react';

export default function Confirmation() {
  const { confirmedPnr, selectedFlightId, selectedSeatId, passengerForm, resetBooking } = useFlightStore();
  const navigate = useNavigate();

  // Clear booking state when leaving this success flow, 
  // Normally we would just load this by querying PNR from Supabase directly
  useEffect(() => {
    return () => resetBooking();
  }, [resetBooking]);

  // If accessed directly without booking
  if (!confirmedPnr || !selectedFlightId) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center p-8">
        <p className="text-white/60 mb-4 font-mono uppercase tracking-wider text-sm">NO ACTIVE BOOKING CONFIRMATION.</p>
        <button onClick={() => navigate('/')} className="text-fuchsia-400 font-medium hover:text-fuchsia-300 uppercase tracking-wider transition-colors">
          Return to home
        </button>
      </div>
    );
  }

  const flight = MOCK_FLIGHTS.find(f => f.id === selectedFlightId);
  const seats = generateMockSeats(selectedFlightId);
  const seat = seats.find(s => s.id === selectedSeatId);

  if (!flight || !seat) return null;

  return (
    <PageTransition>
      <div className="max-w-3xl mx-auto px-4 py-16">
        <div className="bg-white/5 backdrop-blur-xl rounded-3xl p-8 sm:p-12 shadow-2xl border border-white/10 relative overflow-hidden">
          
          <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-bl from-green-500/20 to-transparent rounded-bl-full -z-10" />
          
          <div className="flex flex-col items-center text-center border-b border-white/10 pb-10">
            <div className="w-20 h-20 bg-green-500/20 text-green-400 rounded-full flex items-center justify-center mb-6 shadow-[0_0_30px_rgba(74,222,128,0.2)]">
              <CheckCircle2 className="w-10 h-10" />
            </div>
            <h1 className="text-4xl font-bold text-white tracking-tight mb-4">Booking Confirmed!</h1>
            <p className="text-lg text-white/60">
              Thank you {passengerForm?.fullName}. Your flight to <span className="text-white font-medium">{flight.destination}</span> is successfully booked.
            </p>
          </div>

          <div className="py-10 grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-6">
              <div>
                <span className="text-xs font-mono text-white/50 uppercase tracking-widest">Booking Reference (PNR)</span>
                <div className="text-3xl font-mono text-white mt-1 flex items-center gap-3">
                  {confirmedPnr} 
                  <Ticket className="w-6 h-6 text-fuchsia-400" />
                </div>
              </div>
              
              <div>
                <span className="text-xs font-mono text-white/50 uppercase tracking-widest">Passenger</span>
                <div className="text-xl font-medium text-white mt-1 uppercase tracking-wide">{passengerForm?.fullName}</div>
              </div>
            </div>

            <div className="bg-black/40 p-6 rounded-2xl border border-white/10 space-y-4">
              <div className="flex justify-between items-center border-b border-white/10 pb-3">
                <span className="text-xs font-mono text-white/50 uppercase tracking-wider">Flight</span>
                <span className="font-mono text-white">{flight.flight_no}</span>
              </div>
              <div className="flex justify-between items-center border-b border-white/10 pb-3">
                <span className="text-xs font-mono text-white/50 uppercase tracking-wider">Date</span>
                <span className="font-mono text-white">{format(new Date(flight.departs_at), 'MMM d, yyyy - HH:mm')}</span>
              </div>
              <div className="flex justify-between items-center border-b border-white/10 pb-3">
                <span className="text-xs font-mono text-white/50 uppercase tracking-wider">Seat</span>
                <span className="font-mono text-fuchsia-400 text-lg">{seat.seat_number} <span className="text-xs text-white/50 font-mono ml-1 uppercase">({seat.class})</span></span>
              </div>
              <div className="flex justify-between items-center font-bold text-lg pt-2 text-white">
                <span className="text-xs font-mono text-white/50 uppercase tracking-wider">Total Paid</span>
                <span className="font-mono tracking-tight">${(flight.base_price + seat.extra_fee).toFixed(2)}</span>
              </div>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="px-6 py-3 border border-white/20 hover:border-white/40 hover:bg-white/5 text-white uppercase tracking-wider font-semibold text-sm rounded-xl transition flex text-center justify-center items-center gap-2">
              <Printer className="w-5 h-5 opacity-70" />
              PRINT TICKET
            </button>
            <Link 
              to="/my-bookings" 
              className="px-6 py-3 bg-gradient-to-r from-indigo-500 to-fuchsia-500 hover:opacity-90 text-white uppercase tracking-wider font-semibold text-sm rounded-xl transition flex text-center justify-center items-center shadow-[0_0_20px_rgba(168,85,247,0.4)]"
            >
              MANAGE BOOKINGS
            </Link>
          </div>
        </div>
      </div>
    </PageTransition>
  );
}
