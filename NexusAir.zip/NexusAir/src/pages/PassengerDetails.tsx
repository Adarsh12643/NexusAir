import React, { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { PageTransition } from '../components/PageTransition';
import { useFlightStore } from '../store/useFlightStore';
import { generatePNR } from '../lib/utils';
import { User, CreditCard, Calendar, Flag } from 'lucide-react';

export default function PassengerDetails() {
  const { flightId } = useParams();
  const navigate = useNavigate();
  const { setPassengerForm, setConfirmedPnr, passengerForm, selectedFlightId, selectedSeatId } = useFlightStore();

  const [form, setForm] = useState(passengerForm || {
    fullName: '',
    passportNo: '',
    nationality: '',
    dob: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Fallback if accessed out of order
  if (!selectedFlightId || !selectedSeatId) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center p-8">
        <p className="text-white/60 mb-4 font-mono">PLEASE SELECT A FLIGHT AND SEAT FIRST.</p>
        <button onClick={() => navigate('/')} className="text-fuchsia-400 font-medium hover:text-fuchsia-300 transition-colors uppercase tracking-wider">
          Return to home
        </button>
      </div>
    );
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    setPassengerForm(form);

    // Simulate Supabase RPC call for atomic booking
    // supabase.rpc('reserve_seat', { p_seat_id: selectedSeatId, ... })
    setTimeout(() => {
      const pnr = generatePNR();
      setConfirmedPnr(pnr);
      navigate('/confirmation');
      setIsSubmitting(false);
    }, 1500);
  };

  return (
    <PageTransition>
      <div className="max-w-xl mx-auto px-4 py-12">
        <div className="text-center mb-10">
          <h1 className="text-3xl font-bold text-white tracking-tight mb-2">Passenger Information</h1>
          <p className="text-white/60 font-mono text-sm uppercase tracking-wider">ENTER DETAILS EXACTLY AS THEY APPEAR ON TRAVEL DOCUMENT</p>
        </div>

        <form onSubmit={handleSubmit} className="bg-white/5 backdrop-blur-xl rounded-3xl p-8 shadow-2xl border border-white/10 flex flex-col gap-6">
          
          <div className="space-y-1.5">
            <label className="text-xs font-mono text-white/50 uppercase tracking-wider">Full Name</label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                <User className="h-5 w-5 text-white/40" />
              </div>
              <input
                type="text"
                required
                value={form.fullName}
                onChange={e => setForm({...form, fullName: e.target.value})}
                className="w-full pl-11 pr-4 py-3 bg-black/40 border border-white/10 rounded-xl focus:bg-black/60 focus:ring-2 focus:ring-fuchsia-500/50 focus:border-fuchsia-500/50 transition-all outline-none text-white placeholder-white/30"
                placeholder="John Doe"
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-mono text-white/50 uppercase tracking-wider">Passport Number</label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                <CreditCard className="h-5 w-5 text-white/40" />
              </div>
              <input
                type="text"
                required
                value={form.passportNo}
                onChange={e => setForm({...form, passportNo: e.target.value})}
                className="w-full pl-11 pr-4 py-3 bg-black/40 border border-white/10 rounded-xl focus:bg-black/60 focus:ring-2 focus:ring-fuchsia-500/50 focus:border-fuchsia-500/50 transition-all outline-none text-white placeholder-white/30"
                placeholder="A12345678"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div className="space-y-1.5">
              <label className="text-xs font-mono text-white/50 uppercase tracking-wider">Nationality</label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                  <Flag className="h-5 w-5 text-white/40" />
                </div>
                <input
                  type="text"
                  required
                  value={form.nationality}
                  onChange={e => setForm({...form, nationality: e.target.value})}
                  className="w-full pl-11 pr-4 py-3 bg-black/40 border border-white/10 rounded-xl focus:bg-black/60 focus:ring-2 focus:ring-fuchsia-500/50 focus:border-fuchsia-500/50 transition-all outline-none text-white placeholder-white/30"
                  placeholder="e.g. American"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-mono text-white/50 uppercase tracking-wider">Date of Birth</label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                  <Calendar className="h-5 w-5 text-white/40" />
                </div>
                <input
                  type="date"
                  required
                  value={form.dob}
                  onChange={e => setForm({...form, dob: e.target.value})}
                  className="w-full pl-11 pr-4 py-3 bg-black/40 border border-white/10 rounded-xl focus:bg-black/60 focus:ring-2 focus:ring-fuchsia-500/50 focus:border-fuchsia-500/50 transition-all outline-none text-white [color-scheme:dark]"
                />
              </div>
            </div>
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full bg-gradient-to-r from-indigo-500 to-fuchsia-500 hover:opacity-90 disabled:opacity-50 text-white font-semibold uppercase tracking-wider py-4 rounded-xl mt-4 transition-all shadow-[0_0_20px_rgba(168,85,247,0.4)] flex items-center justify-center"
          >
            {isSubmitting ? (
              <span className="flex items-center gap-2">
                <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                CONFIRMING BOOKING...
              </span>
            ) : "COMPLETE BOOKING"}
          </button>
        </form>
      </div>
    </PageTransition>
  );
}
