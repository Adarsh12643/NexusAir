import { useState, useEffect, useMemo } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { PageTransition } from '../components/PageTransition';
import { useFlightStore } from '../store/useFlightStore';
import { MOCK_FLIGHTS, generateMockSeats } from '../lib/mockData';
import { cn } from '../lib/utils';
import { PlaneTakeoff, Info } from 'lucide-react';

export default function SeatSelection() {
  const { flightId } = useParams();
  const navigate = useNavigate();
  const { setSelectedSeat, selectedSeatId } = useFlightStore();
  
  const [seats, setSeats] = useState<any[]>([]);
  const flight = MOCK_FLIGHTS.find(f => f.id === flightId);

  useEffect(() => {
    // In a real app, we would subscribe to Supabase Realtime here.
    // e.g. supabase.channel('seats').on('postgres_changes', ...).subscribe()
    if (flightId) {
      setSeats(generateMockSeats(flightId));
    }
  }, [flightId]);

  // Group seats by row
  const rows = useMemo(() => {
    const grouped: Record<string, any[]> = {};
    seats.forEach(seat => {
      const rowNum = seat.seat_number.slice(0, -1);
      if (!grouped[rowNum]) grouped[rowNum] = [];
      grouped[rowNum].push(seat);
    });
    // Sort array of row numbers
    return Object.keys(grouped).sort((a, b) => parseInt(a) - parseInt(b)).map(r => ({
      rowNum: r,
      seats: grouped[r].sort((a, b) => a.seat_number.localeCompare(b.seat_number))
    }));
  }, [seats]);

  if (!flight || !seats.length) {
    return <div className="p-8 text-center text-white/50 font-mono text-sm uppercase tracking-wider">Loading Navigation Grid...</div>;
  }

  const handleSeatClick = (seat: any) => {
    if (!seat.is_available) return;
    setSelectedSeat(seat.id);
  };

  const handleContinue = () => {
    if (selectedSeatId) {
      navigate(`/book/${flightId}/passengers`);
    }
  };

  const selectedSeat = seats.find(s => s.id === selectedSeatId);
  const totalPrice = selectedSeat ? flight.base_price + selectedSeat.extra_fee : flight.base_price;

  return (
    <PageTransition>
      <div className="max-w-7xl mx-auto px-4 py-8 flex flex-col md:flex-row gap-8">
        
        {/* Main Seat Map Area */}
        <div className="flex-1 bg-white rounded-3xl shadow-sm border border-slate-200 p-6 sm:p-10 flex flex-col items-center overflow-x-auto relative">
          
          <div className="flex items-center gap-2 mb-8 text-slate-800 border-b border-slate-100 w-full justify-center pb-6">
            <PlaneTakeoff className="w-6 h-6 text-blue-600" />
            <h2 className="text-2xl font-bold tracking-tight">Select your seat</h2>
          </div>

          {/* Cabin visualization (Aircraft shape) */}
          <div className="bg-slate-50 border border-slate-200 rounded-t-[100px] rounded-b-3xl p-6 sm:p-10 min-w-[320px] shadow-inner relative">
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-6 bg-slate-200 rounded-b-full opacity-50"></div>
            
            {rows.map((row) => {
              const rowClass = row.seats[0].class;
              const isFirstInClass = row.rowNum === "1" || 
                                     (rowClass === "business" && row.rowNum === "3") ||
                                     (rowClass === "economy" && row.rowNum === "6");

              return (
                <div key={row.rowNum} className="mb-4">
                  {isFirstInClass && (
                    <div className="w-full text-center mb-6 mt-8">
                      <span className="text-xs font-bold uppercase tracking-widest text-slate-400 border-b border-slate-300 pb-1 px-4">
                        {rowClass} Class
                      </span>
                    </div>
                  )}

                  <div className="flex items-center justify-center gap-2 sm:gap-6">
                    {/* Left block (A, B) */}
                    <div className="flex gap-2">
                      {row.seats.slice(0, 2).map(seat => (
                        <Seat 
                          key={seat.id} 
                          seat={seat} 
                          isSelected={selectedSeatId === seat.id}
                          onClick={() => handleSeatClick(seat)} 
                        />
                      ))}
                    </div>
                    
                    {/* Aisle Row number */}
                    <div className="w-6 sm:w-8 text-center text-xs font-bold text-slate-400">
                      {row.rowNum}
                    </div>

                    {/* Right block (C, D) */}
                    <div className="flex gap-2">
                      {row.seats.slice(2, 4).map(seat => (
                        <Seat 
                          key={seat.id} 
                          seat={seat} 
                          isSelected={selectedSeatId === seat.id}
                          onClick={() => handleSeatClick(seat)} 
                        />
                      ))}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Sidebar Summary */}
        <div className="w-full md:w-80 space-y-6">
          <div className="bg-slate-900 text-white rounded-2xl p-6 shadow-xl relative overflow-hidden">
            <div className="absolute top-0 right-0 p-8 opacity-5">
              <PlaneTakeoff className="w-32 h-32" />
            </div>
            <h3 className="text-xl font-bold mb-4 relative z-10">Trip Summary</h3>
            <div className="space-y-4 text-sm relative z-10">
              <div className="flex justify-between border-b border-slate-700 pb-2">
                <span className="text-slate-400">Flight</span>
                <span className="font-semibold">{flight.flight_no}</span>
              </div>
              <div className="flex justify-between border-b border-slate-700 pb-2">
                <span className="text-slate-400">Route</span>
                <span className="font-semibold">{flight.origin} - {flight.destination}</span>
              </div>
              <div className="flex justify-between border-b border-slate-700 pb-2">
                <span className="text-slate-400">Base Price</span>
                <span className="font-semibold">${flight.base_price.toFixed(2)}</span>
              </div>
              <div className="flex justify-between font-bold text-lg pt-2 mt-4 text-blue-400">
                <span>Total</span>
                <span>${totalPrice.toFixed(2)}</span>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
            <h3 className="font-bold text-slate-800 mb-4">Legend</h3>
            <div className="space-y-3 text-sm">
              <div className="flex items-center gap-3">
                <div className="w-6 h-6 border-2 border-blue-600 bg-blue-50 rounded bg-seat-empty"></div>
                <span className="text-slate-600">Available</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-6 h-6 bg-blue-600 rounded"></div>
                <span className="text-slate-600">Selected</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-6 h-6 bg-slate-200 text-slate-400 flex items-center justify-center rounded">
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </div>
                <span className="text-slate-600">Occupied</span>
              </div>
            </div>
            
            <div className="mt-8 border-t border-slate-100 pt-6">
              {selectedSeat ? (
                <div className="mb-6">
                  <span className="text-xs text-slate-500 uppercase font-bold tracking-wider">Your Seat</span>
                  <div className="text-3xl font-bold text-blue-600 mb-1">{selectedSeat.seat_number}</div>
                  <div className="text-sm font-medium text-slate-600 capitalize">{selectedSeat.class}</div>
                  {selectedSeat.extra_fee > 0 && (
                    <div className="text-sm text-slate-500 mt-1">+${selectedSeat.extra_fee} fee</div>
                  )}
                </div>
              ) : (
                <div className="mb-6 bg-blue-50 text-blue-800 p-4 rounded-xl flex items-start gap-3">
                  <Info className="w-5 h-5 flex-shrink-0 mt-0.5" />
                  <span className="text-sm">Please select a seat from the cabin map to continue your booking.</span>
                </div>
              )}
              
              <button 
                onClick={handleContinue}
                disabled={!selectedSeatId}
                className={cn(
                  "w-full py-4 rounded-xl font-bold text-lg transition-all",
                  selectedSeatId 
                    ? "bg-blue-600 text-white hover:bg-blue-700 shadow-lg shadow-blue-600/20" 
                    : "bg-slate-100 text-slate-400 cursor-not-allowed"
                )}
              >
                Continue
              </button>
            </div>
          </div>

        </div>
      </div>
    </PageTransition>
  );
}

function Seat({ seat, isSelected, onClick }: any) {
  return (
    <div className="relative group">
      <button
        disabled={!seat.is_available}
        onClick={onClick}
        className={cn(
          "relative w-10 h-10 sm:w-12 sm:h-12 rounded-lg sm:rounded-xl border-2 transition-all duration-200 outline-none flex items-center justify-center font-bold text-xs sm:text-sm",
          isSelected 
            ? "bg-blue-600 border-blue-600 text-white scale-110 z-10 shadow-lg" 
            : seat.is_available
              ? seat.class === 'first' 
                ? "border-amber-400 bg-amber-50 text-amber-700 hover:bg-amber-100"
                : seat.class === 'business'
                  ? "border-indigo-400 bg-indigo-50 text-indigo-700 hover:bg-indigo-100"
                  : "border-slate-300 bg-white text-slate-600 hover:border-blue-500 hover:bg-blue-50"
              : "bg-slate-200 border-slate-200 text-slate-400 cursor-not-allowed"
        )}
      >
        {!seat.is_available && (
          <svg className="absolute w-full h-full p-2 opacity-50" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        )}
        {seat.is_available && !isSelected && <span className="opacity-0 group-hover:opacity-100 transition-opacity">{seat.seat_number}</span>}
        {isSelected && seat.seat_number}
      </button>

      {/* Tooltip */}
      <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-32 bg-slate-900 text-white text-xs rounded-lg py-2 px-3 opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity z-50 shadow-xl hidden sm:block">
        <div className="font-bold text-center mb-1">{seat.seat_number} · <span className="capitalize">{seat.class}</span></div>
        <div className="flex justify-between border-t border-slate-700 pt-1 mt-1">
          <span className="text-slate-400">Status</span>
          <span className={seat.is_available ? "text-green-400" : "text-red-400"}>
            {seat.is_available ? 'Available' : 'Occupied'}
          </span>
        </div>
        {seat.extra_fee > 0 && (
          <div className="flex justify-between border-t border-slate-700 pt-1 mt-1">
            <span className="text-slate-400">Class Fee</span>
            <span className="text-amber-400">+${seat.extra_fee}</span>
          </div>
        )}
        {/* Tooltip arrow */}
        <div className="absolute top-full left-1/2 -translate-x-1/2 border-4 border-transparent border-t-slate-900"></div>
      </div>
    </div>
  );
}
