import { useFlightStore } from '../store/useFlightStore';
import { PageTransition } from '../components/PageTransition';
import { MOCK_FLIGHTS } from '../lib/mockData';
import { format, differenceInMinutes } from 'date-fns';
import { Plane, ArrowRight, Clock } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function SearchResults() {
  const { searchQuery, setSelectedFlight } = useFlightStore();
  const navigate = useNavigate();

  if (!searchQuery) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center p-8">
        <p className="text-slate-400 font-mono mb-4 text-sm mt-10">NO QUERY DATA FOUND</p>
        <button onClick={() => navigate('/')} className="text-indigo-400 font-mono text-sm uppercase tracking-widest hover:text-white transition">
          [ RE-INITIALIZE SEARCH ]
        </button>
      </div>
    );
  }

  let results = MOCK_FLIGHTS.filter(f => 
    f.origin.includes(searchQuery.origin) || f.destination.includes(searchQuery.destination)
  );

  if (results.length === 0) {
    results = MOCK_FLIGHTS; 
  }

  const formatDuration = (start: string, end: string) => {
    const diff = differenceInMinutes(new Date(end), new Date(start));
    const hours = Math.floor(diff / 60);
    const mins = diff % 60;
    return `${hours}H ${mins}M`;
  };

  const handleSelect = (id: string) => {
    setSelectedFlight(id);
    navigate(`/book/${id}/seats`);
  };

  return (
    <PageTransition>
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4 border-b border-white/10 pb-6">
          <div>
            <h1 className="text-3xl font-bold text-white tracking-tighter flex items-center gap-4">
              {searchQuery.origin} <ArrowRight className="w-6 h-6 text-fuchsia-500" /> {searchQuery.destination}
            </h1>
            <p className="text-indigo-300 font-mono text-[10px] sm:text-xs tracking-widest mt-2 uppercase">
              SCANNING DEPARTURES // {format(new Date(searchQuery.date), 'dd MMM yyyy')}
            </p>
          </div>
          <div className="text-[10px] uppercase tracking-widest border border-indigo-500/30 rounded-full px-4 py-1.5 bg-indigo-500/10 text-indigo-300 font-mono inline-block">
            {searchQuery.passengers} ENTIT{searchQuery.passengers > 1 ? 'IES' : 'Y'}
          </div>
        </div>

        <div className="space-y-4 relative z-10 w-full overflow-hidden">
          {results.map((flight) => (
            <div 
              key={flight.id}
              className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6 hover:bg-white/10 transition flex flex-col md:flex-row md:items-center justify-between gap-6 relative overflow-hidden group"
            >
              <div className="absolute top-0 left-0 w-1 h-full bg-gradient-to-b from-indigo-500 to-fuchsia-500 opacity-50 group-hover:opacity-100 transition" />
              
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-2">
                  <span className="bg-indigo-500/20 border border-indigo-500/30 text-indigo-300 text-[10px] font-mono tracking-widest px-2.5 py-1 rounded">
                    {flight.flight_no}
                  </span>
                  <span className="text-[10px] font-mono tracking-widest text-slate-400 flex break-words overflow-auto max-w-full uppercase">{flight.aircraft_type}</span>
                </div>
                
                <div className="flex flex-col sm:flex-row sm:items-center justify-between mt-6 gap-6 sm:gap-0">
                  <div className="flex items-center justify-between sm:w-auto w-full sm:flex-col sm:items-start pl-0 sm:pl-0">
                    <span className="text-3xl font-bold tracking-tighter text-white">{format(new Date(flight.departs_at), 'HH:mm')}</span>
                    <span className="text-indigo-400 font-mono text-xs tracking-widest mt-1 uppercase">{flight.origin}</span>
                  </div>
                  
                  <div className="flex flex-col items-center sm:flex-1 w-full px-0 sm:px-8 relative pt-4 sm:pt-0">
                     <div className="w-full absolute top-1/2 -translate-y-1/2 border-t border-dashed border-white/20 hidden sm:block"></div>
                     <Plane className="w-5 h-5 text-fuchsia-400 relative z-10 bg-transparent sm:bg-[#020205] sm:px-1 shadow-none sm:shadow-[0_0_10px_rgba(217,70,239,0.5)] rotate-90 sm:rotate-0 mb-2 sm:mb-0" />
                     <span className="text-[10px] text-slate-400 font-mono tracking-widest mt-0 sm:mt-3 bg-black/40 backdrop-blur-sm px-2 py-0.5 rounded border border-white/5 relative z-10 flex items-center gap-1">
                       <Clock className="w-3 h-3 text-indigo-400" />
                       {formatDuration(flight.departs_at, flight.arrives_at)}
                     </span>
                  </div>

                  <div className="flex items-center justify-between sm:w-auto w-full sm:flex-col sm:items-end">
                    <span className="text-3xl font-bold tracking-tighter text-white">{format(new Date(flight.arrives_at), 'HH:mm')}</span>
                    <span className="text-fuchsia-400 font-mono text-xs tracking-widest mt-1 uppercase">{flight.destination}</span>
                  </div>
                </div>
              </div>

              <div className="border-t md:border-t-0 md:border-l border-white/10 pt-4 md:pt-0 md:pl-8 flex flex-col items-center md:items-end justify-center min-w-[160px]">
                <span className="text-[10px] text-slate-500 font-mono tracking-widest uppercase mb-1">Base</span>
                <span className="text-3xl font-bold text-white tracking-tighter mb-4 flex items-start"><span className="text-sm font-normal text-slate-400 mt-1 mr-1">$</span>{flight.base_price.toFixed(2)}</span>
                <button 
                  onClick={() => handleSelect(flight.id)}
                  className="w-full bg-white/10 hover:bg-indigo-500 text-white text-xs font-bold uppercase tracking-widest py-3 px-6 rounded-xl transition border border-white/10 hover:border-indigo-400 shadow-[0_0_15px_rgba(99,102,241,0)] hover:shadow-[0_0_20px_rgba(99,102,241,0.4)]"
                >
                  TARGET
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </PageTransition>
  );
}
