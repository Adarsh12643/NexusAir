import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export type User = {
  id: string;
  email: string;
  name?: string;
};

interface UserState {
  user: User | null;
  sessionToken: string | null;
  setUser: (user: User | null) => void;
  setSession: (token: string | null) => void;
  logout: () => void;
}

export const useUserStore = create<UserState>()(
  persist(
    (set) => ({
      user: { id: "mock-user-id", email: "guest@example.com", name: "Guest User" }, // Default mock user for demo
      sessionToken: null,
      setUser: (user) => set({ user }),
      setSession: (token) => set({ sessionToken: token }),
      logout: () => set({ user: null, sessionToken: null }),
    }),
    {
      name: 'auth-storage',
      partialize: (state) => ({ sessionToken: state.sessionToken }), // Only persist session
    }
  )
);
