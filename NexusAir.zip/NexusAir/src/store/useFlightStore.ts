import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface SearchQuery {
  origin: string;
  destination: string;
  date: string;
  passengers: number;
}

export interface PassengerFormData {
  fullName: string;
  passportNo: string;
  nationality: string;
  dob: string;
}

interface FlightStoreState {
  searchQuery: SearchQuery | null;
  selectedFlightId: string | null;
  selectedSeatId: string | null;
  currentStep: 'search' | 'results' | 'seats' | 'passengers' | 'confirmation';
  passengerForm: PassengerFormData | null;
  confirmedPnr: string | null;
  
  // Actions
  setSearchQuery: (query: SearchQuery) => void;
  setSelectedFlight: (id: string | null) => void;
  setSelectedSeat: (id: string | null) => void;
  setStep: (step: FlightStoreState['currentStep']) => void;
  setPassengerForm: (data: PassengerFormData) => void;
  setConfirmedPnr: (pnr: string) => void;
  resetBooking: () => void;
}

export const useFlightStore = create<FlightStoreState>()(
  persist(
    (set) => ({
      searchQuery: null,
      selectedFlightId: null,
      selectedSeatId: null,
      currentStep: 'search',
      passengerForm: null,
      confirmedPnr: null,

      setSearchQuery: (query) => set({ searchQuery: query, currentStep: 'results' }),
      setSelectedFlight: (id) => set({ selectedFlightId: id, currentStep: id ? 'seats' : 'search' }),
      setSelectedSeat: (id) => set({ selectedSeatId: id, currentStep: id ? 'passengers' : 'seats' }),
      setStep: (step) => set({ currentStep: step }),
      setPassengerForm: (form) => set({ passengerForm: form }),
      setConfirmedPnr: (pnr) => set({ confirmedPnr: pnr, currentStep: 'confirmation' }),
      resetBooking: () => set({
        selectedFlightId: null,
        selectedSeatId: null,
        currentStep: 'search',
        passengerForm: null,
        confirmedPnr: null
      })
    }),
    {
      name: 'flight-storage',
      partialize: (state) => ({
        searchQuery: state.searchQuery,
        selectedFlightId: state.selectedFlightId,
        selectedSeatId: state.selectedSeatId,
        currentStep: state.currentStep,
        // DONT PERSIST SENSITIVE PASSPORT FORM OR CONFIRMED PNR FOREVER
        passengerForm: state.passengerForm ? { 
          ...state.passengerForm, 
          passportNo: '' 
        } : null
      }),
    }
  )
);
