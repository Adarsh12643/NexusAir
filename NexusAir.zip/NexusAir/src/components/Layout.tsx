import { Outlet, Link, useLocation } from "react-router-dom";
import { Plane, User, List, LogOut } from "lucide-react";
import { useUserStore } from "../store/useUserStore";

export default function Layout() {
  const { user, logout } = useUserStore();
  const location = useLocation();

  return (
    <div className="min-h-screen bg-[#020205] text-slate-200 font-sans flex flex-col relative overflow-hidden">
      {/* Immersive Background Orbs */}
      <div className="absolute top-[-100px] left-[-100px] w-[500px] h-[500px] bg-indigo-600/20 rounded-full blur-[120px] pointer-events-none z-0"></div>
      <div className="absolute bottom-[-100px] right-[-100px] w-[600px] h-[600px] bg-fuchsia-600/20 rounded-full blur-[150px] pointer-events-none z-0"></div>
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[400px] bg-blue-500/5 rounded-full blur-[100px] pointer-events-none z-0"></div>

      <nav className="fixed top-0 left-0 right-0 z-50 bg-black/20 backdrop-blur-md border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            <Link to="/" className="flex items-center gap-3 group">
              <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-fuchsia-600 rounded-xl flex items-center justify-center shadow-[0_0_20px_rgba(99,102,241,0.5)]">
                <Plane className="w-6 h-6 text-white" />
              </div>
              <span className="font-bold text-2xl tracking-tighter text-white">
                NEXUS<span className="text-indigo-400">AIR</span>
              </span>
            </Link>
            
            <div className="flex items-center gap-6">
              {user ? (
                <>
                  <Link 
                    to="/my-bookings" 
                    className={`flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest ${location.pathname === '/my-bookings' ? 'text-white border-b-2 border-indigo-500 pb-1 mt-1' : 'text-slate-400 hover:text-white pb-1 mt-1 border-b-2 border-transparent'} transition`}
                  >
                    <List className="w-3 h-3" />
                    Bookings
                  </Link>
                  <div className="flex items-center gap-4 border-l border-white/10 pl-6">
                    <div className="flex items-center gap-2 text-[10px] text-indigo-300 font-mono">
                      <div className="w-8 h-8 rounded-full border border-indigo-500/50 p-0.5">
                        <div className="w-full h-full rounded-full bg-black/40 flex items-center justify-center text-xs">
                          <User className="w-3 h-3 text-slate-300" />
                        </div>
                      </div>
                      <span className="hidden sm:inline bg-white/5 border border-white/10 px-3 py-1.5 rounded-full uppercase tracking-widest">
                        {user.name}
                      </span>
                    </div>
                    <button 
                      onClick={logout}
                      className="text-slate-400 hover:text-fuchsia-400 transition"
                      title="Log out"
                    >
                      <LogOut className="w-5 h-5" />
                    </button>
                  </div>
                </>
              ) : (
                <button className="text-[10px] font-bold uppercase tracking-widest text-slate-400 hover:text-white transition">
                  Sign In
                </button>
              )}
            </div>
          </div>
        </div>
      </nav>

      <main className="flex-1 pt-20 flex flex-col relative z-10 overflow-y-auto">
        <Outlet />
      </main>
      
      <footer className="relative z-10 px-4 sm:px-8 py-4 bg-black/40 border-t border-white/5 backdrop-blur-xl flex flex-col sm:flex-row items-center justify-between text-[10px] text-slate-500 uppercase tracking-widest font-mono gap-4">
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-emerald-500 rounded-full shadow-[0_0_8px_#10b981]"></div>
            <span className="hidden sm:inline">System: NexusAir Core</span>
          </div>
          <div className="hidden sm:inline">Uptime: 99.9%</div>
        </div>
        <div className="flex items-center gap-4 font-mono text-center">
          &copy; {new Date().getFullYear()} NEXUSAIR. ENCRYPTED.
        </div>
      </footer>
    </div>
  );
}
